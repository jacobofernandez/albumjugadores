# Mundial.
# Albumjugadores

Este programa está creado con el propósito de funcionar como un album, donde el usuario pueda incluir jugadires, teniendo estos diversos atributos.

## Instalación

El código puede ser descargado mediante Bitbucket.

## Uso del *make*

# Suprime los directorios bin y html, elimina los ficheros .jar, los .class y .txt.
    make limpiar

## Crea el directorio bin y allí almacena los .class que ha compilado durante la ejecución del make. 
    make compilar

# Crea el directorio html y los ficheros .html.
    make html
    
# Crea el .jar
    make jar

# Limpia, compila, crea los .jar, los html y ejecuta la interfaz.
    make album
    